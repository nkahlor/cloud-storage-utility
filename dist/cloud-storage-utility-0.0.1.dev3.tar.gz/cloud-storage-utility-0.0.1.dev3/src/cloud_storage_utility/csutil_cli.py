import fnmatch
import glob
import os
import time
import click

from .common.cloud_local_map import CloudLocalMap
from .file_broker import FileBroker

UNLIMITED_ARGS = -1
COUNT = 0

DESIRED_PLATFORM = os.getenv("CSUTIL_DEFAULT_PLATFORM")
if DESIRED_PLATFORM:
    SERVICE = FileBroker(DESIRED_PLATFORM)
else:
    SERVICE = FileBroker()


# Print iterations progress
# pylint: disable=too-many-arguments
def print_progress_bar(total, prefix='', suffix='Complete',
                       decimals=1, length=50, fill='█', print_end="\r"):
    """
    Call in a loop to create terminal progress bar
    @params:
        total       - Required  : total iterations (Int)
        prefix      - Optional  : prefix string (Str)
        suffix      - Optional  : suffix string (Str)
        decimals    - Optional  : positive number of decimals in percent complete (Int)
        length      - Optional  : character length of bar (Int)
        fill        - Optional  : bar fill character (Str)
        printEnd    - Optional  : end character (e.g. "\r", "\r\n") (Str)
    """
    # pylint: disable=global-statement
    global COUNT
    percent = ("{0:." + str(decimals) + "f}").format(100 *
                                                     (COUNT / float(total)))
    filled_length = int(length * COUNT // total)
    progress_bar = fill * filled_length + '-' * (length - filled_length)
    print(f'\r{prefix} |{progress_bar}| {percent}% {suffix}', end=print_end)
    COUNT += 1
    # Print New Line on Complete
    if COUNT == total:
        COUNT = 0
        print()


def time_function(action_function, args):
    """ Executes a function and prints the execution time """
    start_time = time.time()
    action_function(*args)
    print("Action complete in %.4f sec" % (time.time() - start_time))


def local_file_exists(local_filepath):
    """ See if a file exists on the local machine """
    return os.path.exists(local_filepath)


def add_if_file_exists(cloud_map_list, filepath):
    """ If the file exists, add it to the map list """
    if local_file_exists(filepath):
        cloud_map_list.append(
            CloudLocalMap(
                os.path.basename(filepath),
                filepath))
    else:
        print(f"Warning: {filepath} could not be uploaded, it doesn't exist.")


@click.group()
@click.option('-v/-s', '--verbose/--silent',
              default=False, help="Print detailed logs")
@click.pass_context
def execute_cli(ctx, verbose):
    """ Entry point for the CLI """
    ctx.ensure_object(dict)
    ctx.obj['verbose'] = verbose


@execute_cli.command()
@click.argument('bucket-name', type=click.STRING)
def list_remote(bucket_name):
    """ List contents of bucket """
    print(*SERVICE.get_bucket_keys(bucket_name), sep="\n")


@execute_cli.command()
@click.argument('cloud-bucket', type=click.STRING)
@click.argument('local-file-pattern', type=click.STRING, nargs=UNLIMITED_ARGS)
@click.pass_context
def push(ctx, local_file_pattern, cloud_bucket):
    """ Push files from local machine to the cloud bucket """
    patterns = list(local_file_pattern)
    cloud_map_list = []
    for pattern in patterns:
        pattern_expansion = glob.glob(pattern, recursive=False)
        # Either the pattern expansion is a list of files, or it's a file
        # itself
        if len(pattern_expansion) == 0:
            add_if_file_exists(cloud_map_list, pattern)
        else:
            for filepath in pattern_expansion:
                add_if_file_exists(cloud_map_list, filepath)

    if len(cloud_map_list) > 0:
        if ctx.obj['verbose']:
            print("Pushing")
            print("-" * 10)
            # I only want to print the individual filenames
            list_to_print = list(
                map(lambda x: os.path.basename(x.local_filepath), cloud_map_list))
            print(*list_to_print, sep="\n")
            print(f"to {cloud_bucket}\n")

            time_function(SERVICE.upload_files,
                          (cloud_bucket, cloud_map_list, print_progress_bar, (len(list_to_print), "Uploading")))
        else:
            time_function(SERVICE.upload_files, (cloud_bucket, cloud_map_list))
    else:
        print("Nothing to push.")


@execute_cli.command()
@click.argument('bucket-name', type=click.STRING)
@click.argument('destination-dir',
                type=click.Path(exists=True, file_okay=False))
@click.argument('cloud-key-wildcard', type=click.STRING, nargs=UNLIMITED_ARGS)
@click.pass_context
def pull(ctx, destination_dir, bucket_name, cloud_key_wildcard):
    """ Pull files from the cloud bucket to the local machine """
    # Get the names of all the files in the bucket
    bucket_contents = SERVICE.get_bucket_keys(bucket_name)

    # Filter out the ones we need
    keys_to_download = []
    for wildcard in cloud_key_wildcard:
        keys_to_download += fnmatch.filter(bucket_contents, wildcard)

    if len(keys_to_download) > 0:
        if ctx.obj['verbose']:
            print("Pulling")
            print("-" * 10)
            print(*keys_to_download, sep="\n")
            print(f"from {bucket_name}")

            time_function(
                SERVICE.download_files,
                (destination_dir, bucket_name, keys_to_download,
                 print_progress_bar, (len(keys_to_download), "Downloading"))
            )
        else:
            time_function(
                SERVICE.download_files,
                (destination_dir, bucket_name, keys_to_download)
            )

    else:
        print("No matching files found in the specified cloud bucket.")


@execute_cli.command()
@click.argument('bucket-name', type=click.STRING)
@click.argument('cloud-key-wildcard', type=click.STRING, nargs=UNLIMITED_ARGS)
@click.pass_context
def delete(ctx, cloud_key_wildcard, bucket_name):
    """ Delete files from the cloud bucket """
    bucket_contents = SERVICE.get_bucket_keys(bucket_name)

    keys_to_delete = []
    for wildcard in cloud_key_wildcard:
        keys_to_delete += fnmatch.filter(bucket_contents, wildcard)

    if len(keys_to_delete) > 0:
        if ctx.obj['verbose']:
            print("Deleting")
            print("-" * 10)
            print(*keys_to_delete, sep="\n")
            print(f"from {bucket_name}")
        time_function(SERVICE.remove_items, (bucket_name, keys_to_delete))
    else:
        print("No matching files found in the specified cloud bucket.")


def main():
    """ Main entry point """
    # pylint: disable=no-value-for-parameter
    execute_cli()
