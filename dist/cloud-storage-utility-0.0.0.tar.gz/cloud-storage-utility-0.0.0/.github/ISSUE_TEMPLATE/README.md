Issue templates created in this folder will automatically be picked up by Github and included as Issue types for the repo:

![](delete-me.png)