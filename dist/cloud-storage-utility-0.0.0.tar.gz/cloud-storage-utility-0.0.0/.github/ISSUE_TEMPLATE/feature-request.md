---
name: Feature Request
about: Make a Feature Request
labels: Feature request, needs review
---

### Pre-requisites:
<!-- Add a check to each item below by replacing "[ ]" with "[x]" (no spaces inside the brackets, lowercase x) -->
- [ ] Yes, I looked through both [open and closed issues](../issues?utf8=✓&q=is%3Aissue) looking for what I needed

## Feature Description
<!-- What does your new feature do? How would users interact with it/use it? -->

## Additional Details
<!-- This is your space to add anything you think is relevant -->