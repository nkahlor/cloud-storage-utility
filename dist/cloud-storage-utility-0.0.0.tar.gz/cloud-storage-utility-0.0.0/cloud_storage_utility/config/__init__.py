"""Holds various configuration options for all platforms."""
