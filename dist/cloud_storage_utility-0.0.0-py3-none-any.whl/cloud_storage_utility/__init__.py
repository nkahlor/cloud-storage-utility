"""
## Welcome to the API documentation!

For most applications, the `file_broker` module will be all you need.

If you want to add a new platform implementation, checkout `common/base_cloud_storage` and `platforms/`.
"""
